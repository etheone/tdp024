package se.liu.ida.tdp024.account.xfinal.test.util;

public interface FinalConstants {
    
    public static final String ENDPOINT = "http://localhost:8080/account-rest/";
    
}
