package se.liu.ida.tdp024.account.rest.service;

public class AccountService {

    
    
}
