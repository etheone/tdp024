package se.liu.ida.tdp024.account.logic.api.facade;


public interface AccountLogicFacade {
    
}
