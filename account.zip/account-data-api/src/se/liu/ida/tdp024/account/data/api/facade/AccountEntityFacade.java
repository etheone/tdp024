package se.liu.ida.tdp024.account.data.api.facade;

public interface AccountEntityFacade {
    
}
