package se.liu.ida.tdp024.account.data.api.util;

public interface StorageFacade {
    
    void emptyStorage();
    
}
